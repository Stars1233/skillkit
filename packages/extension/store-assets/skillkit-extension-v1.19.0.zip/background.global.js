"use strict";
(() => {
  // src/background.ts
  var API_URL = "https://agenstskills.com/api/save-skill";
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "save-page",
      title: "Save page as Skill",
      contexts: ["page"]
    });
    chrome.contextMenus.create({
      id: "save-selection",
      title: "Save selection as Skill",
      contexts: ["selection"]
    });
  });
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (!tab?.id) return;
    try {
      if (info.menuItemId === "save-page") {
        const url = tab.url ?? "";
        if (!url || url.startsWith("chrome://") || url.startsWith("about:")) {
          notifyTab(tab.id, { error: "Cannot save skills from this page" });
          return;
        }
        const result = await callSaveApi(url);
        if (!("error" in result)) {
          downloadSkill(result.name, result.skillMd);
        }
        notifyTab(tab.id, result);
      }
      if (info.menuItemId === "save-selection" && info.selectionText) {
        const url = tab.url ?? "";
        const result = buildSelectionSkill(info.selectionText, url);
        downloadSkill(result.name, result.skillMd);
        notifyTab(tab.id, result);
      }
    } catch {
      notifyTab(tab.id, { error: "Failed to save skill" });
    }
  });
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      if (message.type === "SAVE_PAGE") {
        const { url, name } = message.payload;
        callSaveApi(url, name).then((result) => {
          if (!("error" in result)) {
            downloadSkill(result.name, result.skillMd);
          }
          sendResponse(result);
        }).catch(() => {
          sendResponse({ error: "Failed to save skill" });
        });
        return true;
      }
      if (message.type === "SAVE_SELECTION") {
        const { text, url, name } = message.payload;
        const result = buildSelectionSkill(text, url, name);
        downloadSkill(result.name, result.skillMd);
        sendResponse(result);
      }
      return false;
    }
  );
  async function callSaveApi(url, name) {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, name })
    });
    let data;
    try {
      data = await response.json();
    } catch {
      return { error: `Server error: ${response.status}` };
    }
    if (!response.ok) {
      return { error: data.error ?? `Server error: ${response.status}` };
    }
    return {
      name: data.name,
      filename: `${data.name}/SKILL.md`,
      skillMd: data.skillMd,
      tags: data.tags ?? []
    };
  }
  function buildSelectionSkill(text, url, name) {
    const skillName = slugify(name || "selection");
    const savedAt = (/* @__PURE__ */ new Date()).toISOString();
    const skillMd = `---
name: ${skillName}
description: Selected text saved as skill
metadata:
` + (url ? `  source: ${yamlEscape(url)}
` : "") + `  savedAt: ${savedAt}
---

` + text + "\n";
    return {
      name: skillName,
      filename: `${skillName}/SKILL.md`,
      skillMd,
      tags: []
    };
  }
  function yamlEscape(value) {
    const singleLine = value.replace(/\r?\n/g, " ").trim();
    if (/[:#{}[\],&*?|>!%@`]/.test(singleLine) || singleLine.startsWith("'") || singleLine.startsWith('"')) {
      return `"${singleLine.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
    }
    return singleLine;
  }
  function slugify(input) {
    const slug = input.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").replace(/-{2,}/g, "-");
    return slug.slice(0, 64).replace(/-+$/, "") || "untitled-skill";
  }
  function downloadSkill(name, skillMd) {
    const blob = new Blob([skillMd], { type: "text/markdown" });
    const blobUrl = URL.createObjectURL(blob);
    chrome.downloads.download({
      url: blobUrl,
      filename: `skillkit-skills/${name}/SKILL.md`,
      saveAs: false
    }, () => {
      URL.revokeObjectURL(blobUrl);
    });
  }
  function notifyTab(tabId, result) {
    const isError = "error" in result;
    chrome.action.setBadgeText({ text: isError ? "!" : "\u2713", tabId });
    chrome.action.setBadgeBackgroundColor({ color: isError ? "#ef4444" : "#22c55e", tabId });
    setTimeout(() => chrome.action.setBadgeText({ text: "", tabId }), 3e3);
  }
})();
